const API_URL = 'http://localhost:54420';
console.log('Health component using API URL:', API_URL); 