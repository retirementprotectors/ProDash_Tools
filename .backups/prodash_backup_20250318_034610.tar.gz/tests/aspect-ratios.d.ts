export declare const aspectRatios: {
    square: {
        value: string;
    };
    landscape: {
        value: string;
    };
    portrait: {
        value: string;
    };
    wide: {
        value: string;
    };
    ultrawide: {
        value: string;
    };
    golden: {
        value: string;
    };
};
