# ProDash Tools

A comprehensive toolkit for AI-assisted development with context management and project scaffolding.

## Directory Structure

This project has been refactored. The main code is now located in the `prodash-tools` directory.

See `prodash-tools/README.md` for full documentation.

## Quick Start

```bash
# Install dependencies
npm install

# Start the server
npm start

# Start the dashboard
npm run dev:dashboard

# Set up shell integration
source ./prodash-tools/cli/command_wrapper.sh

# Create a new project
prodash-create my-project
```
