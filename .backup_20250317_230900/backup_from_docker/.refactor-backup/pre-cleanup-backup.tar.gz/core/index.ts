/**
 * ProDash_Tools Core
 * 
 * This file re-exports core utilities from Context Keeper and other modules
 * to make them easily accessible across all projects.
 */

// Context Management
export { ContextManager } from '../context-keeper/core/ContextManager';
export { Context } from '../context-keeper/core/ContextManager';

// Port Management
export { 
  findAvailablePort, 
  DEFAULT_PORTS,
  generatePortFromProjectName,
  getProjectName
} from '../context-keeper/core/PortConfig';

// Backup Management
export { BackupManager } from '../context-keeper/core/BackupManager';

// Monitoring and Health
export { MonitoringService } from '../context-keeper/core/MonitoringService';

// Git Integration
export { GitIntegration } from '../context-keeper/core/GitIntegration';

// Context Capture
export { ContextCaptureService } from '../context-keeper/core/ContextCaptureService';

// Re-export interface types
import { MonitoringService } from '../context-keeper/core/MonitoringService';

/**
 * Types from MonitoringService
 */
// These are internal types in MonitoringService.ts that we're exposing
export type HealthMetrics = {
  memoryUsage: number;
  cpuUsage: number;
  contextCount: number;
  backupCount: number;
  lastBackupTime: number;
  timestamp: number;
};

export type Alert = {
  id: string;
  type: string;
  message: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  timestamp: number;
  acknowledged: boolean;
  resolved: boolean;
  metadata?: Record<string, any>;
};

export type AlertSeverity = 'info' | 'warning' | 'error' | 'critical';

/**
 * Get a single context manager instance
 * @returns A singleton ContextManager instance
 */
let contextManagerInstance: any = null;
export function getContextManager() {
  if (!contextManagerInstance) {
    const { ContextManager } = require('../context-keeper/core/ContextManager');
    contextManagerInstance = new ContextManager();
    contextManagerInstance.initialize().catch(console.error);
  }
  return contextManagerInstance;
}

/**
 * Get a single backup manager instance
 * @returns A singleton BackupManager instance
 */
let backupManagerInstance: any = null;
export function getBackupManager() {
  if (!backupManagerInstance) {
    const { BackupManager } = require('../context-keeper/core/BackupManager');
    backupManagerInstance = new BackupManager();
    backupManagerInstance.initialize().catch(console.error);
  }
  return backupManagerInstance;
}

/**
 * Get a single monitoring service instance
 * @returns A singleton MonitoringService instance
 */
let monitoringServiceInstance: any = null;
export function getMonitoringService() {
  if (!monitoringServiceInstance) {
    const { MonitoringService } = require('../context-keeper/core/MonitoringService');
    monitoringServiceInstance = new MonitoringService();
    monitoringServiceInstance.initialize().catch(console.error);
  }
  return monitoringServiceInstance;
} 