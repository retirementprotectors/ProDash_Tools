import { Router } from 'express';
import { ContextManager } from '../core/ContextManager';

export function contextRoutes(contextManager: ContextManager) {
  const router = Router();
  
  // Get all contexts
  router.get('/', async (req, res) => {
    try {
      const contexts = await contextManager.getAllContexts();
      res.json(contexts);
    } catch (error) {
      console.error('Error getting contexts:', error);
      res.status(500).json({ 
        error: 'Failed to get contexts',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Get a specific context by ID
  router.get('/:id', async (req, res) => {
    try {
      const context = await contextManager.getContext(req.params.id);
      
      if (context) {
        res.json(context);
      } else {
        res.status(404).json({ error: 'Context not found' });
      }
    } catch (error) {
      console.error('Error getting context:', error);
      res.status(500).json({ 
        error: 'Failed to get context',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Create a new context
  router.post('/', async (req, res) => {
    try {
      const { content, metadata } = req.body;
      
      if (!content) {
        return res.status(400).json({ error: 'Content is required' });
      }
      
      const context = await contextManager.addContext(content, metadata || {});
      res.status(201).json(context);
    } catch (error) {
      console.error('Error creating context:', error);
      res.status(500).json({ 
        error: 'Failed to create context',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Update an existing context
  router.put('/:id', async (req, res) => {
    try {
      const { content, metadata } = req.body;
      const id = req.params.id;
      
      if (!content) {
        return res.status(400).json({ error: 'Content is required' });
      }
      
      const updatedContext = await contextManager.updateContext(id, content, metadata);
      
      if (updatedContext) {
        res.json(updatedContext);
      } else {
        res.status(404).json({ error: 'Context not found' });
      }
    } catch (error) {
      console.error('Error updating context:', error);
      res.status(500).json({ 
        error: 'Failed to update context',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Delete a context
  router.delete('/:id', async (req, res) => {
    try {
      const id = req.params.id;
      const success = await contextManager.deleteContext(id);
      
      if (success) {
        res.json({ message: 'Context deleted successfully' });
      } else {
        res.status(404).json({ error: 'Context not found' });
      }
    } catch (error) {
      console.error('Error deleting context:', error);
      res.status(500).json({ 
        error: 'Failed to delete context',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Search contexts
  router.get('/search/:query', async (req, res) => {
    try {
      const query = req.params.query;
      const results = await contextManager.searchContexts(query);
      res.json(results);
    } catch (error) {
      console.error('Error searching contexts:', error);
      res.status(500).json({ 
        error: 'Failed to search contexts',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  return router;
} 