# Context Keeper

Context Keeper is a robust system for maintaining and managing chat contexts. It provides features for context storage, backup, health monitoring, and dashboard visualization.

## Architecture

Context Keeper is built with a modular architecture consisting of the following components:

### Core Services

- **ContextManager**: Stores and retrieves conversation contexts, including metadata
- **BackupManager**: Handles automatic backups of all context data
- **MonitoringService**: Tracks system health and collects metrics
- **GitIntegration**: Provides version control integration
- **ContextCaptureService**: Automatically captures and updates contexts

### API Layer

RESTful API endpoints for each core service, allowing frontend and external systems to interact with Context Keeper:

- `/api/contexts`: Manage conversation contexts
- `/api/backups`: Trigger backups and restore from backups
- `/api/monitoring`: Get system metrics and alerts
- `/api/health`: Check system health
- `/api/git`: Manage git integration
- `/api/capture`: Control context capture behavior

### Dashboard

A React-based dashboard that provides visualization and management of:

- Contexts
- Backups
- Monitoring metrics
- System alerts

## Dynamic Port Configuration

Context Keeper uses dynamic port assignment based on project name:

- **Frontend**: 51xxx range
- **Backend**: 52xxx range
- **Database**: 53xxx range

This ensures consistent port assignments across different projects and minimizes port conflicts.

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Start the backend server:
```bash
npm run dev
```

3. Start the frontend development server:
```bash
cd context-keeper/dashboard/public && npm run dev
```

## Integrating with Your Project

To use Context Keeper in your projects:

1. Import the core services:
```typescript
import { ContextManager } from './context-keeper/core/ContextManager';
import { BackupManager } from './context-keeper/core/BackupManager';
import { MonitoringService } from './context-keeper/core/MonitoringService';
```

2. Initialize the services:
```typescript
const contextManager = new ContextManager();
await contextManager.initialize();
```

3. Use the Context API to store and retrieve contexts:
```typescript
// Add a context
await contextManager.addContext({
  id: 'conversation-123',
  content: 'User asked about implementing a feature. We discussed options A and B.',
  timestamp: Date.now(),
  metadata: {
    topic: 'Feature Implementation',
    tags: ['feature', 'development'],
    participants: ['User', 'Assistant']
  }
});

// Get contexts
const contexts = await contextManager.getContexts();
```

## Features

- **Context Storage**: Save conversation contexts with rich metadata
- **Automatic Backups**: Schedule regular backups of all contexts
- **Health Monitoring**: Track system health metrics
- **Git Integration**: Version control for context data
- **Dashboard**: Visual interface for managing the system
- **Dynamic Port Configuration**: Avoid port conflicts with smart port assignment

## Advanced Configuration

See the individual services for advanced configuration options:

- `ContextManager.setConfig()`
- `BackupManager.setBackupConfig()`
- `MonitoringService.setMonitoringConfig()`
- `ContextCaptureService.setConfig()` 