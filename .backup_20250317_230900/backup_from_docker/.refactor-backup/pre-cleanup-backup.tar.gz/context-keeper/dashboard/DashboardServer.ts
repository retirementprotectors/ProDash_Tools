import express from 'express';
import { Server } from 'http';
import path from 'path';
import { ContextManager } from '../core/ContextManager';
import { BackupManager } from '../core/BackupManager';
import { MonitoringService } from '../core/MonitoringService';
import cors from 'cors';

export class DashboardServer {
  private app: express.Application;
  private server: Server | null;
  private port: number;
  private maxPortAttempts: number;

  constructor(port = 3000, maxPortAttempts = 10) {
    this.app = express();
    this.server = null;
    this.port = port;
    this.maxPortAttempts = maxPortAttempts;
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware() {
    this.app.use(express.json());
    
    // Configure CORS for development
    this.app.use(cors({
      origin: ['http://localhost:5173', 'http://localhost:4000', 'http://localhost:5174'],
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization']
    }));
    
    // Static file serving
    this.app.use(express.static(path.join(__dirname, 'public')));
  }

  private setupRoutes() {
    // Context routes
    this.app.get('/api/contexts', async (req, res) => {
      try {
        const contextManager = new ContextManager();
        await contextManager.initialize();
        const contexts = await contextManager.getAllContexts();
        res.json(contexts || []);
      } catch (error) {
        console.error('Error fetching contexts:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    this.app.get('/api/contexts/search', async (req, res) => {
      try {
        const { query } = req.query;
        if (!query || typeof query !== 'string') {
          return res.status(400).json({ error: 'Query parameter required' });
        }

        const contextManager = new ContextManager();
        await contextManager.initialize();
        const results = await contextManager.searchContexts(query);
        res.json(results || []);
      } catch (error) {
        console.error('Error searching contexts:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Add new context
    this.app.post('/api/contexts', async (req, res) => {
      try {
        const { content, metadata } = req.body;
        
        if (!content) {
          return res.status(400).json({ error: 'Content is required' });
        }
        
        const contextManager = new ContextManager();
        await contextManager.initialize();
        
        const newContext = await contextManager.addContext(content, metadata || {});
        res.status(201).json(newContext);
      } catch (error) {
        console.error('Error adding context:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Backup routes
    this.app.get('/api/backups', async (req, res) => {
      try {
        const backupManager = new BackupManager();
        await backupManager.initialize();
        const backups = await backupManager.listBackups();
        res.json(backups || []);
      } catch (error) {
        console.error('Error fetching backups:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    this.app.post('/api/backups/create', async (req, res) => {
      try {
        const contextManager = new ContextManager();
        const backupManager = new BackupManager();
        
        await contextManager.initialize();
        await backupManager.initialize();
        
        const contexts = await contextManager.getAllContexts();
        const backupFile = await backupManager.createBackup(contexts);
        res.json({ backupFile });
      } catch (error) {
        console.error('Error creating backup:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    this.app.post('/api/backups/restore/:filename', async (req, res) => {
      const { filename } = req.params;
      
      try {
        const contextManager = new ContextManager();
        const backupManager = new BackupManager();
        
        await contextManager.initialize();
        await backupManager.initialize();
        
        const contexts = await backupManager.restoreBackup(filename);
        res.json({ success: true, contextCount: contexts.length });
      } catch (error) {
        console.error('Error restoring backup:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Get backup configuration
    this.app.get('/api/backups/config', async (req, res) => {
      try {
        const backupManager = new BackupManager();
        await backupManager.initialize();
        
        const config = backupManager.getBackupConfig();
        res.json(config);
      } catch (error) {
        console.error('Error getting backup config:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Update backup configuration
    this.app.post('/api/backups/config', async (req, res) => {
      try {
        const { autoBackupEnabled, backupFrequencyMs, retentionPeriodDays } = req.body;
        
        const backupManager = new BackupManager();
        await backupManager.initialize();
        
        const updatedConfig = {
          autoBackupEnabled: autoBackupEnabled !== undefined ? Boolean(autoBackupEnabled) : undefined,
          backupFrequencyMs: backupFrequencyMs !== undefined ? Number(backupFrequencyMs) : undefined,
          retentionPeriodDays: retentionPeriodDays !== undefined ? Number(retentionPeriodDays) : undefined
        };
        
        backupManager.setBackupConfig(updatedConfig);
        
        res.json({
          success: true,
          config: backupManager.getBackupConfig()
        });
      } catch (error) {
        console.error('Error updating backup config:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Trigger a manual backup
    this.app.post('/api/backups/trigger', async (req, res) => {
      try {
        const contextManager = new ContextManager();
        const backupManager = new BackupManager();
        
        await contextManager.initialize();
        await backupManager.initialize();
        
        const contexts = await contextManager.getAllContexts();
        const backupFile = await backupManager.createBackup(contexts);
        
        res.json({
          success: true,
          backupFile,
          message: 'Manual backup triggered successfully'
        });
      } catch (error) {
        console.error('Error triggering backup:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Monitoring routes
    this.app.get('/api/metrics', async (req, res) => {
      try {
        const { start, end } = req.query;
        const monitoringService = new MonitoringService();
        
        await monitoringService.initialize();
        
        const timeRange = start && end 
          ? { start: Number(start), end: Number(end) }
          : undefined;
        
        const metrics = await monitoringService.getMetrics();
        
        // Filter metrics based on time range if provided
        const filteredMetrics = timeRange
          ? metrics.filter(metric => 
              metric.timestamp >= timeRange.start && 
              metric.timestamp <= timeRange.end)
          : metrics;
        
        res.json(filteredMetrics || []);
      } catch (error) {
        console.error('Error fetching metrics:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    this.app.get('/api/alerts', async (req, res) => {
      try {
        const { includeResolved } = req.query;
        const monitoringService = new MonitoringService();
        
        await monitoringService.initialize();
        
        const alerts = await monitoringService.getAlerts(
          includeResolved === 'true'
        );
        res.json(alerts || []);
      } catch (error) {
        console.error('Error fetching alerts:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    this.app.post('/api/alerts/:id/resolve', async (req, res) => {
      try {
        const { id } = req.params;
        const monitoringService = new MonitoringService();
        
        await monitoringService.initialize();
        
        const alert = await monitoringService.resolveAlert(id);
        if (alert) {
          res.json(alert);
        } else {
          res.status(404).json({ error: 'Alert not found' });
        }
      } catch (error) {
        console.error('Error resolving alert:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        res.status(500).json({ error: errorMessage });
      }
    });

    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.json({ status: 'healthy', timestamp: Date.now() });
    });

    // API status endpoint
    this.app.get('/api/status', (req, res) => {
      res.json({ 
        status: 'operational',
        timestamp: Date.now(),
        version: '1.0.0'
      });
    });

    // Serve the React app for all other routes
    this.app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'public', 'index.html'));
    });
  }

  async findAvailablePort(startPort: number, maxAttempts = 10): Promise<number> {
    let port = startPort;
    let attempts = 0;
    
    while (attempts < maxAttempts) {
      try {
        // Create a server to test if port is available
        const server = require('net').createServer();
        
        // Use a promise to handle the async port testing
        const available = await new Promise<boolean>((resolve) => {
          server.once('error', (err: NodeJS.ErrnoException) => {
            if (err.code === 'EADDRINUSE') {
              resolve(false);
            }
          });
          
          server.once('listening', () => {
            // Port is available
            server.close();
            resolve(true);
          });
          
          server.listen(port);
        });
        
        if (available) {
          console.log(`Found available port: ${port}`);
          return port;
        }
        
        // Port is not available, try the next one
        console.log(`Port ${port} is in use, trying port ${port + 1}...`);
        port++;
        attempts++;
      } catch (error) {
        console.log(`Error checking port ${port}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        port++;
        attempts++;
      }
    }
    
    console.warn(`Could not find available port after ${maxAttempts} attempts. Falling back to default port.`);
    console.warn(`Note: If the server fails to start, try manually specifying a different port or closing some applications.`);
    console.warn(`You can check which applications are using ports with: lsof -i -P | grep LISTEN`);
    return startPort;
  }

  async start(): Promise<void> {
    try {
      // Try to find an available port
      this.port = await this.findAvailablePort(this.port, this.maxPortAttempts);
      
      return new Promise((resolve, reject) => {
        try {
          this.server = this.app.listen(this.port, () => {
            console.log(`Dashboard server running at http://localhost:${this.port}`);
            resolve();
          });
          
          this.server.on('error', (err: NodeJS.ErrnoException) => {
            if (err.code === 'EADDRINUSE') {
              console.error(`Port ${this.port} is already in use. Please try a different port or close the application using this port.`);
              console.error('You can check which applications are using ports with: lsof -i -P | grep LISTEN');
            } else {
              console.error('Server error:', err.message);
            }
            reject(err);
          });
        } catch (innerError) {
          console.error('Error starting server:', innerError instanceof Error ? innerError.message : innerError);
          reject(innerError);
        }
      });
    } catch (error) {
      console.error('Failed to start server:', error instanceof Error ? error.message : error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.server) {
        resolve();
        return;
      }

      this.server.close((err) => {
        if (err) {
          reject(err);
        } else {
          this.server = null;
          resolve();
        }
      });
    });
  }

  /**
   * Returns the current port the server is using
   */
  getPort(): number {
    return this.port;
  }
} 