#!/usr/bin/env node

/**
 * Context Tools
 * 
 * Command-line utility for working with the Context Keeper system.
 * Provides commands for managing contexts, backups, and monitoring.
 */

const { resolve } = require('path');
const { existsSync } = require('fs');

// Ensure we're in the right directory and can load the Context Keeper modules
const projectRoot = resolve(__dirname, '..');
process.chdir(projectRoot);

// Check TypeScript environment
const isTsNodeAvailable = existsSync(`${projectRoot}/node_modules/.bin/ts-node`);
const loaderPath = isTsNodeAvailable 
  ? `${projectRoot}/node_modules/.bin/ts-node`
  : 'node';

// Command map
const COMMANDS = {
  'help': showHelp,
  'list': listContexts,
  'get': getContext,
  'add': addContext,
  'backup': triggerBackup,
  'restore': restoreBackup,
  'list-backups': listBackups,
  'health': checkHealth,
};

async function main() {
  // Get command line arguments
  const args = process.argv.slice(2);
  const command = args[0] || 'help';
  
  if (!COMMANDS[command]) {
    console.error(`Unknown command: ${command}`);
    showHelp();
    process.exit(1);
  }
  
  try {
    // Execute the command with remaining arguments
    await COMMANDS[command](args.slice(1));
  } catch (error) {
    console.error(`Error executing command ${command}:`, error);
    process.exit(1);
  }
}

// Command implementations
function showHelp() {
  console.log(`
Context Tools - Command-line utility for Context Keeper

Usage: 
  node scripts/context-tools.js <command> [options]

Commands:
  help                   Show this help message
  list                   List all contexts
  get <id>               Get a specific context by ID
  add <file>             Add a context from a JSON file
  backup                 Trigger a manual backup
  restore <file>         Restore from a backup file
  list-backups           List all available backups
  health                 Check system health
  
Examples:
  node scripts/context-tools.js list
  node scripts/context-tools.js get 1234567890
  node scripts/context-tools.js backup
  `);
}

async function loadContextManager() {
  // For TypeScript: Import dynamically based on environment
  const { getContextManager } = isTsNodeAvailable
    ? require('../core')
    : require('../dist/core');
    
  return getContextManager();
}

async function loadBackupManager() {
  // For TypeScript: Import dynamically based on environment
  const { getBackupManager } = isTsNodeAvailable
    ? require('../core')
    : require('../dist/core');
    
  return getBackupManager();
}

async function loadMonitoringService() {
  // For TypeScript: Import dynamically based on environment
  const { getMonitoringService } = isTsNodeAvailable
    ? require('../core')
    : require('../dist/core');
    
  return getMonitoringService();
}

async function listContexts() {
  const contextManager = await loadContextManager();
  const contexts = await contextManager.getContexts();
  
  console.log('Available contexts:');
  
  if (contexts.length === 0) {
    console.log('No contexts found.');
    return;
  }
  
  contexts.forEach(context => {
    const date = new Date(context.timestamp).toLocaleString();
    console.log(`- ID: ${context.id}`);
    console.log(`  Date: ${date}`);
    console.log(`  Content: ${context.content.substring(0, 100)}${context.content.length > 100 ? '...' : ''}`);
    console.log('');
  });
}

async function getContext(args) {
  if (!args[0]) {
    console.error('Error: Context ID is required');
    return;
  }
  
  const contextId = args[0];
  const contextManager = await loadContextManager();
  const contexts = await contextManager.getContexts();
  
  const context = contexts.find(c => c.id === contextId);
  
  if (!context) {
    console.error(`Context with ID ${contextId} not found.`);
    return;
  }
  
  console.log(JSON.stringify(context, null, 2));
}

async function addContext(args) {
  if (!args[0]) {
    console.error('Error: JSON file path is required');
    return;
  }
  
  const filePath = args[0];
  const { readFileSync } = require('fs');
  
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const contextData = JSON.parse(fileContent);
    
    const contextManager = await loadContextManager();
    await contextManager.addContext(contextData);
    
    console.log(`Context added successfully: ${contextData.id}`);
  } catch (error) {
    console.error('Error adding context:', error);
  }
}

async function triggerBackup() {
  const backupManager = await loadBackupManager();
  const result = await backupManager.createBackup();
  
  console.log(`Backup created successfully: ${result.filename}`);
}

async function restoreBackup(args) {
  if (!args[0]) {
    console.error('Error: Backup filename is required');
    return;
  }
  
  const filename = args[0];
  const backupManager = await loadBackupManager();
  
  try {
    await backupManager.restoreFromBackup(filename);
    console.log(`Restored from backup: ${filename}`);
  } catch (error) {
    console.error('Error restoring from backup:', error);
  }
}

async function listBackups() {
  const backupManager = await loadBackupManager();
  const backups = await backupManager.getBackups();
  
  console.log('Available backups:');
  
  if (backups.length === 0) {
    console.log('No backups found.');
    return;
  }
  
  backups.forEach(backup => {
    const date = new Date(backup.timestamp).toLocaleString();
    console.log(`- Filename: ${backup.filename}`);
    console.log(`  Date: ${date}`);
    console.log(`  Contexts: ${backup.contextCount}`);
    console.log('');
  });
}

async function checkHealth() {
  const monitoringService = await loadMonitoringService();
  const result = await monitoringService.runHealthCheck();
  
  console.log('Health check results:');
  console.log(`- Status: ${result.success ? 'Healthy' : 'Unhealthy'}`);
  
  if (result.issues.length > 0) {
    console.log('- Issues:');
    result.issues.forEach(issue => console.log(`  - ${issue}`));
  } else {
    console.log('- No issues detected');
  }
  
  // Get latest metrics
  const metrics = await monitoringService.getMetrics();
  if (metrics.length > 0) {
    const latest = metrics[metrics.length - 1];
    console.log('\nLatest metrics:');
    console.log(`- Memory usage: ${Math.round(latest.memoryUsage / (1024 * 1024))} MB`);
    console.log(`- Context count: ${latest.contextCount}`);
    console.log(`- Backup count: ${latest.backupCount}`);
    
    if (latest.lastBackupTime) {
      const backupDate = new Date(latest.lastBackupTime).toLocaleString();
      console.log(`- Last backup: ${backupDate}`);
    }
  }
}

// Run the main function
main().catch(console.error); 