# Port Conflict Resolution in Context Keeper

The Context Keeper system includes an automatic port conflict resolution feature that ensures it can start even when the default port is already in use by another application.

## How It Works

1. When the Dashboard Server starts, it attempts to use the default port (3000 by default).
2. If the default port is already in use, the system automatically searches for the next available port.
3. The system will try up to 20 ports by default (e.g., 3000, 3001, 3002, etc.) before giving up.
4. Once an available port is found, the system starts on that port and displays a message indicating the actual port being used.

## Using Custom Ports

You can specify a custom port to use via command line arguments:

```bash
# Start the Context Keeper on port 8080
npx ts-node context-keeper/index.ts --port 8080
```

## Additional Options

You can also configure how many alternative ports the system will try:

```bash
# Try up to 50 alternative ports
npx ts-node context-keeper/index.ts --max-port-attempts 50
```

## Troubleshooting Port Conflicts

If the system fails to start due to port conflicts, you can:

1. Specify a different port using the `--port` option
2. Check which applications are using ports with: `lsof -i -P | grep LISTEN`
3. Close applications that are using the ports you need
4. Restart the Context Keeper system

## Testing the Port Conflict Resolution

A test script is available to verify that the port conflict resolution works correctly:

```bash
npx ts-node scripts/test-port-conflict.ts
```

This script creates a dummy server on a specified port and then attempts to start the Dashboard Server on the same port, verifying that it correctly finds an alternative port. 