#!/bin/bash

# More aggressive cleanup script that will definitely remove all redundant files

echo "🧹 Starting aggressive cleanup..."

# Kill any running processes
echo "Stopping any running node processes..."
killall node 2>/dev/null || true
sleep 2

# Create backup first (just to be safe)
echo "Creating final backup before aggressive cleanup..."
mkdir -p .refactor-backup
tar -czf .refactor-backup/pre-final-cleanup-$(date +%s).tar.gz --exclude=".refactor-backup" --exclude="node_modules" .

# List directories and files to be forcefully removed
TO_REMOVE=(
  "context-keeper"
  "core"
  "scripts"
  "services"
  "dist"
  "plugins"
  "docs"
  ".context-keeper"
  "templates"
)

# Remove each directory with force
for dir in "${TO_REMOVE[@]}"; do
  if [ -d "$dir" ]; then
    echo "Removing $dir..."
    rm -rf "$dir"
  fi
done

# Clean up files at root level that might be outdated
ROOT_FILES_TO_CLEAN=(
  "TROUBLESHOOTING.md"
  "USAGE.md"
  "tsconfig.json"
  "requirements.txt"
)

for file in "${ROOT_FILES_TO_CLEAN[@]}"; do
  if [ -f "$file" ]; then
    echo "Removing $file..."
    rm -f "$file"
  fi
done

# Make sure prodash-tools has all the needed directories
mkdir -p prodash-tools/core/context-keeper
mkdir -p prodash-tools/core/utils
mkdir -p prodash-tools/api/routes
mkdir -p prodash-tools/dashboard/public/src/components
mkdir -p prodash-tools/cli
mkdir -p prodash-tools/templates/basic-project
mkdir -p prodash-tools/docs
mkdir -p prodash-tools/tests

echo ""
echo "✅ Aggressive cleanup complete!"
echo "Your ProDash Tools directory should now be organized."
echo "The only directories that should remain are:"
echo "- prodash-tools/ (your new clean structure)"
echo "- node_modules/ (needed dependencies)"
echo "- .git/ (version control)"
echo "- .refactor-backup/ (your backups)" 