# Context Keeper Usage Guide

## Accessing the Dashboard

The Context Keeper dashboard is available at:
- **URL**: http://localhost:5173
- **API Endpoint**: http://localhost:4000

## Main Features

### 1. Context Management
- View and search through stored conversation contexts
- Filter contexts by metadata
- View context details and history

### 2. Backup Management
- Create new backups of all contexts
- Restore from previous backups
- View backup history and metadata

### 3. System Monitoring
- View real-time system metrics
- Monitor memory and CPU usage
- Track context count and system health

### 4. Alerts
- View system alerts and warnings
- Resolve alerts when addressed
- Configure alert settings

## Docker Setup

The system runs in Docker containers for easy deployment and isolation:

```bash
# Start the system
docker-compose up -d

# Check service status
./scripts/check-services.sh

# View logs
docker-compose logs -f

# Stop the system
docker-compose down
```

## API Endpoints

### Context Management
- `GET /api/contexts` - List all contexts
- `GET /api/contexts/search?query=text` - Search contexts

### Backup Management
- `GET /api/backups` - List all backups
- `POST /api/backups/create` - Create a new backup
- `POST /api/backups/restore/:filename` - Restore from backup

### System Monitoring
- `GET /api/metrics` - Get system metrics
- `GET /api/alerts` - Get system alerts
- `POST /api/alerts/:id/resolve` - Resolve an alert

## Troubleshooting

### Services Not Starting
1. Check if the ports are already in use: `lsof -i :4000` and `lsof -i :5173`
2. Check Docker logs: `docker-compose logs -f`
3. Restart the services: `docker-compose restart`

### Data Persistence
All data is stored in a Docker volume named `context-keeper-data` for persistence.

### Dashboard Not Loading
1. Verify the backend is running: `curl http://localhost:4000/health`
2. Check browser console for errors
3. Ensure the API URL is correctly configured in the frontend

## Development

For development purposes, you can run the services separately:

```bash
# Backend
npm run dev

# Frontend
cd context-keeper/dashboard/public && npm run dev
``` 