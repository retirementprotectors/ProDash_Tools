import express from 'express';
import cors from 'cors';
import { join } from 'path';
import { ContextManager } from '../context-keeper/core/ContextManager';
import { BackupManager } from '../context-keeper/core/BackupManager';
import { GitIntegration } from '../context-keeper/core/GitIntegration';
import { ContextCaptureService } from '../context-keeper/core/ContextCaptureService';
import { DEFAULT_PORTS, findAvailablePort } from '../context-keeper/core/PortConfig';

// API routes
import { contextRoutes } from '../context-keeper/api/contextRoutes';
import { backupRoutes } from '../context-keeper/api/backupRoutes';
import { healthRoutes } from '../context-keeper/api/healthRoutes';
import { gitRoutes } from '../context-keeper/api/gitRoutes';
import { captureRoutes } from '../context-keeper/api/captureRoutes';

// Managers
const contextManager = new ContextManager();
const backupManager = new BackupManager();
const gitIntegration = new GitIntegration();
const captureService = new ContextCaptureService();

async function startServer() {
  console.log('Initializing Context Keeper...');

  try {
    // Initialize services
    console.log('Initializing Context Manager...');
    await contextManager.initialize();

    console.log('Initializing Backup Manager...');
    await backupManager.initialize();
    
    console.log('Initializing Git Integration...');
    await gitIntegration.initialize();
    
    console.log('Initializing Context Capture Service...');
    await captureService.initialize();

    // Create Express app
    const app = express();
    
    // Set up middleware
    app.use(cors());
    app.use(express.json({ limit: '50mb' }));
    
    // Set up API routes
    app.use('/api/contexts', contextRoutes(contextManager));
    app.use('/api/backups', backupRoutes(backupManager, contextManager));
    app.use('/api/health', healthRoutes(contextManager, backupManager));
    app.use('/api/git', gitRoutes(gitIntegration));
    app.use('/api/capture', captureRoutes(captureService));

    // Serve static files from the dashboard
    app.use(express.static(join(__dirname, '..', 'context-keeper', 'dashboard', 'public', 'dist')));
    
    // Catch-all route to serve the dashboard for client-side routing
    app.get('*', (req, res) => {
      res.sendFile(join(__dirname, '..', 'context-keeper', 'dashboard', 'public', 'dist', 'index.html'));
    });

    // Try to use the default port, but find an available one if that's not possible
    console.log(`Starting Dashboard Server (attempting to use port ${DEFAULT_PORTS.BACKEND})...`);
    const port = await findAvailablePort(DEFAULT_PORTS.BACKEND);
    
    // Save the actual port so frontend can access it
    app.set('port', port);
    
    // Start server
    app.listen(port, () => {
      console.log(`Dashboard server running at http://localhost:${port}`);
      console.log('Context Keeper system is running!');
      console.log(`Access the dashboard at http://localhost:${port}`);
    });

    // Set up graceful shutdown
    process.on('SIGINT', async () => {
      console.log('Shutting down Context Keeper...');
      
      // Perform cleanup
      await backupManager.shutdown();
      await gitIntegration.shutdown();
      await captureService.shutdown();
      
      process.exit(0);
    });
  } catch (error) {
    console.error('Failed to start Context Keeper:', error);
    process.exit(1);
  }
}

// Start the server
startServer(); 