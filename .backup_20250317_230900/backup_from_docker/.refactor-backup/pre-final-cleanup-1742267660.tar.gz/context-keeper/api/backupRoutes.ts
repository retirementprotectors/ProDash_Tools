import { Router } from 'express';
import { BackupManager } from '../core/BackupManager';
import { ContextManager } from '../core/ContextManager';

export function backupRoutes(backupManager: BackupManager, contextManager: ContextManager) {
  const router = Router();
  
  // Get all backups
  router.get('/', async (req, res) => {
    try {
      const backups = await backupManager.listBackups();
      res.json(backups);
    } catch (error) {
      console.error('Error getting backups:', error);
      res.status(500).json({ 
        error: 'Failed to get backups',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Get backup configuration
  router.get('/config', async (req, res) => {
    try {
      const config = backupManager.getBackupConfig();
      res.json(config);
    } catch (error) {
      console.error('Error getting backup configuration:', error);
      res.status(500).json({ 
        error: 'Failed to get backup configuration',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Update backup configuration
  router.post('/config', async (req, res) => {
    try {
      const config = req.body;
      backupManager.setBackupConfig(config);
      
      // Return the updated config
      const updatedConfig = backupManager.getBackupConfig();
      res.json({ 
        message: 'Backup configuration updated successfully',
        config: updatedConfig
      });
    } catch (error) {
      console.error('Error updating backup configuration:', error);
      res.status(500).json({ 
        error: 'Failed to update backup configuration',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Manually trigger a backup
  router.post('/trigger', async (req, res) => {
    try {
      // Get all contexts to back up
      const contexts = await contextManager.getAllContexts();
      
      // Create the backup
      const backupFile = await backupManager.createBackup(contexts);
      
      res.json({ 
        message: 'Backup created successfully',
        backupFile
      });
    } catch (error) {
      console.error('Error creating backup:', error);
      res.status(500).json({ 
        error: 'Failed to create backup',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Restore from backup
  router.post('/restore/:filename', async (req, res) => {
    try {
      const filename = req.params.filename;
      
      // Restore contexts from the backup
      const contexts = await backupManager.restoreBackup(filename);
      
      // Replace all existing contexts with the ones from the backup
      await contextManager.clearAllContexts();
      
      // Add each context from the backup
      let contextCount = 0;
      for (const context of contexts) {
        await contextManager.addContext(context.content, context.metadata);
        contextCount++;
      }
      
      res.json({ 
        message: 'Backup restored successfully',
        contextCount
      });
    } catch (error) {
      console.error('Error restoring backup:', error);
      res.status(500).json({ 
        error: 'Failed to restore backup',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  return router;
} 