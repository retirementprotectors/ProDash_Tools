#!/bin/bash

# ProDash_Tools Command Wrapper
# This script provides global access to ProDash_Tools utilities
# Add to .zshrc: source ~/Projects/ProDash_Tools/scripts/command_wrapper.sh

# Get the directory of this script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PRODASH_ROOT="$( dirname "$SCRIPT_DIR" )"

# Add aliases for commonly used commands
alias context-tools="node $PRODASH_ROOT/scripts/context-tools.js"
alias ct="node $PRODASH_ROOT/scripts/context-tools.js"
alias prodash="cd $PRODASH_ROOT"

# Function to start ProDash services
prodash-start() {
  echo "Starting ProDash services..."
  cd "$PRODASH_ROOT" && npm run dev &
  sleep 3
  cd "$PRODASH_ROOT/context-keeper/dashboard/public" && npm run dev &
  echo "Services started. Access the dashboard at the port shown in console."
}

# Function to stop ProDash services
prodash-stop() {
  echo "Stopping ProDash services..."
  pkill -f "node.*context-keeper"
  echo "Services stopped."
}

# Function to create a new project with ProDash_Tools integration
prodash-create() {
  if [ -z "$1" ]; then
    echo "Usage: prodash-create <project-name>"
    return 1
  fi
  
  PROJECT_NAME="$1"
  PROJECT_DIR="$HOME/Projects/$PROJECT_NAME"
  
  # Check if project already exists
  if [ -d "$PROJECT_DIR" ]; then
    echo "Error: Project $PROJECT_NAME already exists at $PROJECT_DIR"
    return 1
  fi
  
  # Create project directory
  mkdir -p "$PROJECT_DIR"
  cd "$PROJECT_DIR"
  
  # Initialize git repository
  git init
  
  # Copy essential files from ProDash_Tools
  cp "$PRODASH_ROOT/package.json" .
  cp "$PRODASH_ROOT/tsconfig.json" .
  
  # Update package.json with project name
  sed -i '' "s/\"name\": \"context-keeper\"/\"name\": \"$PROJECT_NAME\"/" package.json
  
  # Create essential directories
  mkdir -p src
  mkdir -p services
  mkdir -p plugins
  
  # Create symbolic link to ProDash_Tools core
  ln -s "$PRODASH_ROOT/core" core
  ln -s "$PRODASH_ROOT/context-keeper" context-keeper
  
  # Create basic README.md
  echo "# $PROJECT_NAME

This project is built on ProDash_Tools.

## Getting Started

1. Install dependencies:
\`\`\`bash
npm install
\`\`\`

2. Start the development server:
\`\`\`bash
npm run dev
\`\`\`

## Features

- Context-aware conversations
- Automatic backups
- Health monitoring
- Dashboard visualization
" > README.md

  # Create index.ts
  echo "import express from 'express';
import { ContextManager, BackupManager, MonitoringService } from './core';

async function main() {
  // Initialize services
  const contextManager = await ContextManager.getInstance();
  const backupManager = await BackupManager.getInstance();
  const monitoringService = await MonitoringService.getInstance();
  
  // Create app
  const app = express();
  
  // Start server
  const port = 3000;
  app.listen(port, () => {
    console.log(\`Server running at http://localhost:\${port}\`);
  });
}

main().catch(console.error);
" > src/index.ts

  # Install dependencies
  npm install
  
  echo "Project $PROJECT_NAME created successfully at $PROJECT_DIR"
}

# Export functions and paths
export PRODASH_ROOT

echo "ProDash_Tools command wrapper loaded."
echo "Available commands:"
echo "  context-tools, ct     - Access context tools" 
echo "  prodash               - Navigate to ProDash_Tools directory"
echo "  prodash-start         - Start all ProDash services"
echo "  prodash-stop          - Stop all ProDash services"
echo "  prodash-create <name> - Create a new project with ProDash_Tools integration" 