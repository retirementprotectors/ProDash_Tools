# Context Keeper Troubleshooting Guide

## Common Issues and Solutions

### "Error fetching contexts" in Dashboard

If you see "Error fetching contexts" with status code 500:

1. Check that the backend server is running:
   ```bash
   # Check if backend is accessible
   curl http://localhost:3000/api/contexts
   ```

2. Make sure the API URL is correctly configured in `.env`:
   ```
   VITE_API_URL=http://localhost:3000
   ```

3. Restart both services:
   ```bash
   # Kill existing processes
   pkill -f "ts-node"
   pkill -f "vite"
   
   # Start backend
   npm run dev
   
   # Start frontend (in a new terminal)
   cd context-keeper/dashboard/public && npm run dev
   ```

### Port Conflicts

If you encounter "EADDRINUSE" errors (port already in use):

1. Find and kill the process using the port:
   ```bash
   # For port 3000 (backend)
   lsof -i :3000
   kill -9 <PID>
   
   # For port 5173 (frontend)
   lsof -i :5173
   kill -9 <PID>
   ```

2. Or use different ports by setting environment variables:
   ```bash
   # For backend
   PORT=3001 npm run dev
   
   # For frontend, edit vite.config.ts to use a different port
   # or set SERVER_PORT=5174 before running
   ```

### Data Storage Issues

If the system doesn't save or load contexts/backups:

1. Check that the data directories exist and have correct permissions:
   ```bash
   mkdir -p .context-keeper/contexts
   mkdir -p .context-keeper/backups
   mkdir -p .context-keeper/monitoring
   ```

2. Check for file permission issues:
   ```bash
   ls -la .context-keeper/
   ```

### Docker-related Issues

If Docker containers aren't starting:

1. Check Docker logs:
   ```bash
   docker-compose logs
   ```

2. Rebuild and restart:
   ```bash
   docker-compose down
   docker-compose up --build
   ```

3. Check for port conflicts:
   ```bash
   docker ps -a
   ```

### TypeScript Compilation Errors

If you encounter TypeScript errors:

1. Install missing dependencies:
   ```bash
   npm install
   ```

2. Clear TypeScript cache:
   ```bash
   rm -rf node_modules/.cache
   ```

3. Check for module resolution issues:
   ```bash
   npx tsc --noEmit
   ```

## Quick Start (Without Docker)

To run the application without Docker:

1. Start the backend:
   ```bash
   npm run dev
   ```

2. Start the frontend:
   ```bash
   cd context-keeper/dashboard/public && npm run dev
   ```

3. Access the dashboard at http://localhost:5173

## Checking Service Status

Run the check script to verify if services are running:

```bash
./scripts/check-services.sh
``` 